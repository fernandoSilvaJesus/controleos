<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta content="text/html; charset=ISO-8859-1"
http-equiv="content-type">
<title>FORMULARIO DE TESTE</title>
</head>
<body>

<form action="envia_fale.php" method="post" name="form">

FORMULARIO DE TESTE<br>
<br>
<br>
NOME:<br>
<input name="nome"><br>
<br>
EMAIL:<br>
<input name="email"><br>
<br>
ASSUNTO:<br>
<input name="assunto"><br>
<br>
MENSAGEM:<br>
<input name="mensagem"><br>
<br><br>
<input type="submit" name="submit" value="submit"><br>
</form>
<br>
<br>
<br>
</body>
</html>

